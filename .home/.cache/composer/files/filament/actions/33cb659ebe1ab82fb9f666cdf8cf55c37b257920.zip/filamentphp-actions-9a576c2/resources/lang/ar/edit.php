<?php

return [

    'single' => [

        'label' => 'تعديل',

        'modal' => [

            'heading' => 'تعديل :label',

            'actions' => [

                'save' => [
                    'label' => 'حفظ',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'تم الحفظ',
            ],

        ],

    ],

];
