<?php

return [

    'single' => [

        'label' => 'Spajanje',

        'modal' => [

            'heading' => 'Spojite :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Zapis',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Spoji',
                ],

                'associate_another' => [
                    'label' => 'Spojite i spojite još jedan',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Spojeno',
            ],

        ],

    ],

];
