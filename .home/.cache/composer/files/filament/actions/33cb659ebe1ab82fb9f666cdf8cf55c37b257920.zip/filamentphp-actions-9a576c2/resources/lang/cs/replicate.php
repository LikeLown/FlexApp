<?php

return [

    'single' => [

        'label' => 'Duplikovat',

        'modal' => [

            'heading' => 'Duplikovat :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikovat',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Záznam duplikován',
            ],

        ],

    ],

];
