<?php

return [

    'single' => [

        'label' => 'Associate',

        'modal' => [

            'heading' => 'Associate :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Associate',
                ],

                'associate_another' => [
                    'label' => 'Associate & associate another',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Associated',
            ],

        ],

    ],

];
