<?php

return [

    'single' => [

        'label' => 'Replicate',

        'modal' => [

            'heading' => 'Replicate :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Replicate',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Replicated',
            ],

        ],

    ],

];
