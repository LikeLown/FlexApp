<?php

return [

    'single' => [

        'label' => 'जोड़े',

        'modal' => [

            'heading' => ':label जोड़े',

            'fields' => [

                'record_id' => [
                    'label' => 'रिकार्ड्स',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'जोड़े',
                ],

                'attach_another' => [
                    'label' => 'इसे जोड़े और एक और जोड़े',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'जुड़ गया',
            ],

        ],

    ],

];
