<?php

return [

    'single' => [

        'label' => 'Törlés',

        'modal' => [

            'heading' => ':label törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Törölve',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Kiválasztottak törlése',

        'modal' => [

            'heading' => 'Kiválasztott :label törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Törölve',
            ],

        ],

    ],

];
