<?php

return [

    'single' => [

        'label' => '追加',

        'modal' => [

            'heading' => ':labelの追加',

            'fields' => [

                'record_id' => [
                    'label' => 'レコード',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => '追加',
                ],

                'attach_another' => [
                    'label' => '追加して、続けて追加',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => '追加しました',
            ],

        ],

    ],

];
