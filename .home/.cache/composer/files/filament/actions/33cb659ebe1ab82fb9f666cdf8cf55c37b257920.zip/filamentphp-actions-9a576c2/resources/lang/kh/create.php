<?php

return [

    'single' => [

        'label' => 'បង្កើត',

        'modal' => [

            'heading' => 'បង្កើត :label',

            'actions' => [

                'create' => [
                    'label' => 'បង្កើត',
                ],

                'create_another' => [
                    'label' => 'បង្កើត & បង្កើតឡើងវិញ',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'បានបង្កើតដោយជោគជ័យ',
            ],

        ],

    ],

];
