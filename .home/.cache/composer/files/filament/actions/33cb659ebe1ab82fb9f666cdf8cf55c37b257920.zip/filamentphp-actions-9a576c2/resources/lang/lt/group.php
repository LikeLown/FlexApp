<?php

return [

    'trigger' => [
        'label' => 'Veiksmai',
    ],

];
