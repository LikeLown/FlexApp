<?php

return [

    'single' => [

        'label' => 'Хавсаргах',

        'modal' => [

            'heading' => 'Хавсаргах :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Бичлэг',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Хавсаргах',
                ],

                'attach_another' => [
                    'label' => 'Хадгалаад & ахиад шинийг үүсгэх',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Амжилттай',
            ],

        ],

    ],

];
