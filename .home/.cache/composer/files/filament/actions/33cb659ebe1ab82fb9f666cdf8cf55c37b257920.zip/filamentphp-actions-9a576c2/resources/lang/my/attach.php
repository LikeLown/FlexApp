<?php

return [

    'single' => [

        'label' => 'ပူးတွဲရန်',

        'modal' => [

            'heading' => ':label ပူးတွဲရန်',

            'fields' => [

                'record_id' => [
                    'label' => 'မှတ်တမ်းများ',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'ပူးတွဲရန်',
                ],

                'attach_another' => [
                    'label' => 'သိမ်းဆည်းပြီး နောက်တစ်ခုကို ဖန်တီးပါ',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'သိမ်းဆည်းပြီး',
            ],

        ],

    ],

];
