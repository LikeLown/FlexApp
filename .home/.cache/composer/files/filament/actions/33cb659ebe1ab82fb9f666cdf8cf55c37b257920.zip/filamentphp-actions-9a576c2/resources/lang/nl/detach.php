<?php

return [

    'single' => [

        'label' => 'Ontkoppelen',

        'modal' => [

            'heading' => ':Label ontkoppelen',

            'actions' => [

                'detach' => [
                    'label' => 'Ontkoppelen',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Ontkoppeld',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Geselecteerde ontkoppelen',

        'modal' => [

            'heading' => 'Geselecteerde :label ontkoppelen',

            'actions' => [

                'detach' => [
                    'label' => 'Ontkoppelen',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Ontkoppeld',
            ],

        ],

    ],

];
