<?php

return [

    'single' => [

        'label' => 'Løsne',

        'modal' => [

            'heading' => 'Løsne fra :label',

            'actions' => [

                'detach' => [
                    'label' => 'Løsne fra',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Løsnet',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Løsne fra valgte',

        'modal' => [

            'heading' => 'Løsne fra valgte :label',

            'actions' => [

                'detach' => [
                    'label' => 'Løsne fra',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Løsnet',
            ],

        ],

    ],

];
