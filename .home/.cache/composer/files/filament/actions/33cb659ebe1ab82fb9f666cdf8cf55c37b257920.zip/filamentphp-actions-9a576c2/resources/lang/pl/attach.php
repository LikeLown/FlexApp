<?php

return [

    'single' => [

        'label' => 'Dołącz',

        'modal' => [

            'heading' => 'Dołącz :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Rekord',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Dołącz',
                ],

                'attach_another' => [
                    'label' => 'Dołącz i dołącz kolejny',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Dołączono',
            ],

        ],

    ],

];
