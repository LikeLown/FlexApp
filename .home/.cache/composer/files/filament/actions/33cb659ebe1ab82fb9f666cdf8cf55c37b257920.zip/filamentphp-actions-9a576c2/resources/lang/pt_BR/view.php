<?php

return [

    'single' => [

        'label' => 'Visualizar',

        'modal' => [

            'heading' => 'Visualizar :label',

            'actions' => [

                'close' => [
                    'label' => 'Fechar',
                ],

            ],

        ],

    ],

];
