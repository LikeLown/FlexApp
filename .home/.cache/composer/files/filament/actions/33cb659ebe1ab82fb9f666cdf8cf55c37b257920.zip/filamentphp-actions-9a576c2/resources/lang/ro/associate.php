<?php

return [

    'single' => [

        'label' => 'Asociere',

        'modal' => [

            'heading' => 'Asociere :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Înregistrare',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Asociere',
                ],

                'associate_another' => [
                    'label' => 'Asociați și asociați altul',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Asociat cu succes',
            ],

        ],

    ],

];
