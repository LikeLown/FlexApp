<?php

return [

    'single' => [

        'label' => 'Adăugare :label',

        'modal' => [

            'heading' => 'Creare :label',

            'actions' => [

                'create' => [
                    'label' => 'Creare',
                ],

                'create_another' => [
                    'label' => 'Creați și creați altul',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Creat cu succes',
            ],

        ],

    ],

];
