<?php

return [

    'single' => [

        'label' => 'Editare',

        'modal' => [

            'heading' => 'Editare :label',

            'actions' => [

                'save' => [
                    'label' => 'Salvare',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Salvat cu succes',
            ],

        ],

    ],

];
