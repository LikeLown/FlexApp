<?php

return [

    'single' => [

        'label' => 'Отделить',

        'modal' => [

            'heading' => 'Отделено :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Отделить',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Отделено',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Отделить отмеченное',

        'modal' => [

            'heading' => 'Отделить отмеченное :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Отделить отмеченное',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Отделено',
            ],

        ],

    ],

];
