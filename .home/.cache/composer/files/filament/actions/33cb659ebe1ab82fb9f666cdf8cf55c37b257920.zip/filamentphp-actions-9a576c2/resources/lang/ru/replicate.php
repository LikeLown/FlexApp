<?php

return [

    'single' => [

        'label' => 'Копировать',

        'modal' => [

            'heading' => 'Копировать :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Копировать',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Запись скопирована',
            ],

        ],

    ],

];
