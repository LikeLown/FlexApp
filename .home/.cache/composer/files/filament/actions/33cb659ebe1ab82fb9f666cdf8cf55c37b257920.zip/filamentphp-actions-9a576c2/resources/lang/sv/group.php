<?php

return [

    'trigger' => [
        'label' => 'Åtgärder',
    ],

];
