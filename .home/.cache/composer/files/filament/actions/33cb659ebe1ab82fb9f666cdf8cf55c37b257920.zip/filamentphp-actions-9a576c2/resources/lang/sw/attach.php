<?php

return [

    'single' => [

        'label' => 'Pakia',

        'modal' => [

            'heading' => 'Pakia :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Rekodi',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Pakia',
                ],

                'attach_another' => [
                    'label' => 'Pakia na pakia tena',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Imepakiwa',
            ],

        ],

    ],

];
