<?php

return [

    'single' => [

        'label' => 'Tenganisha',

        'modal' => [

            'heading' => 'Tenganisha :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tenganisha',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Imetenganishwa',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Tenganisha chaguo',

        'modal' => [

            'heading' => 'Tenganisha chaguo :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tenganisha',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Imetenganishwa',
            ],

        ],

    ],

];
