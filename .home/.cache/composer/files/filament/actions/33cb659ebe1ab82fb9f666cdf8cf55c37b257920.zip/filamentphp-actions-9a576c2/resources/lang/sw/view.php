<?php

return [

    'single' => [

        'label' => 'Angalia',

        'modal' => [

            'heading' => 'Angalia :label',

            'actions' => [

                'close' => [
                    'label' => 'Funga',
                ],

            ],

        ],

    ],

];
