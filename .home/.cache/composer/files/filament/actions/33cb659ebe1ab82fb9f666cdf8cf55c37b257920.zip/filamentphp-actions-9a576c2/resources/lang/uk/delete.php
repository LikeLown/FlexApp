<?php

return [

    'single' => [

        'label' => 'Видалити',

        'modal' => [

            'heading' => 'Видалити :label',

            'actions' => [

                'delete' => [
                    'label' => 'Видалити',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Видалено',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Видалити вибране',

        'modal' => [

            'heading' => 'Видалити вибране :label',

            'actions' => [

                'delete' => [
                    'label' => 'Видалити',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Видалено',
            ],

        ],

    ],

];
