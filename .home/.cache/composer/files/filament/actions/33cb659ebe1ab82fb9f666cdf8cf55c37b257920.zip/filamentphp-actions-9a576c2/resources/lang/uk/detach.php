<?php

return [

    'single' => [

        'label' => 'Від’єднати',

        'modal' => [

            'heading' => 'Від’єднати :label',

            'actions' => [

                'detach' => [
                    'label' => 'Від’єднати',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Від’єднано',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Від’єднати вибране',

        'modal' => [

            'heading' => 'Від’єднати вибране :label',

            'actions' => [

                'detach' => [
                    'label' => 'Від’єднати',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Від’єднано',
            ],

        ],

    ],

];
