<?php

return [

    'single' => [

        'label' => 'Видалити назавжди',

        'modal' => [

            'heading' => 'Видалити назавжди :label',

            'actions' => [

                'delete' => [
                    'label' => 'Видалити',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Запис видалено',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Видалити назавжди обране',

        'modal' => [

            'heading' => 'Видалити назавжди обране :label',

            'actions' => [

                'delete' => [
                    'label' => 'Видалити',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Записи видалено',
            ],

        ],

    ],

];
