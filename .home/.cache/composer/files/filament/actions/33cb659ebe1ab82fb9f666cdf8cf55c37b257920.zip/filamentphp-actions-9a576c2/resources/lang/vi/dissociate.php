<?php

return [

    'single' => [

        'label' => 'Huỷ liên kết',

        'modal' => [

            'heading' => 'Huỷ liên kết :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Huỷ liên kết',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Đã huỷ liên kết',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Huỷ liên kết các mục đã chọn',

        'modal' => [

            'heading' => 'Huỷ liên kết :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Huỷ liên kết',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Đã huỷ liên kết',
            ],

        ],

    ],

];
