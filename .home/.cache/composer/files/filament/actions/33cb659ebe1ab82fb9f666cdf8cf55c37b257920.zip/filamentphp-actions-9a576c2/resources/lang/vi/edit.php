<?php

return [

    'single' => [

        'label' => 'Sửa',

        'modal' => [

            'heading' => 'Sửa :label',

            'actions' => [

                'save' => [
                    'label' => 'Lưu thay đổi',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Đã lưu',
            ],

        ],

    ],

];
