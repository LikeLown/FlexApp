<?php

return [

    'single' => [

        'label' => 'Xem',

        'modal' => [

            'heading' => 'Xem :label',

            'actions' => [

                'close' => [
                    'label' => 'Đóng',
                ],

            ],

        ],

    ],

];
