<?php

return [

    'single' => [

        'label' => '编辑',

        'modal' => [

            'heading' => '编辑 :label',

            'actions' => [

                'save' => [
                    'label' => '保存',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => '已保存',
            ],

        ],

    ],

];
