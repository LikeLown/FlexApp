<?php

return [

    'single' => [

        'label' => '复制',

        'modal' => [

            'heading' => '复制 :label',

            'actions' => [

                'replicate' => [
                    'label' => '复制',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => '记录已复制',
            ],

        ],

    ],

];
