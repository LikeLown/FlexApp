<?php

return [

    'single' => [

        'label' => '查看',

        'modal' => [

            'heading' => '查看 :label',

            'actions' => [

                'close' => [
                    'label' => '关闭',
                ],

            ],

        ],

    ],

];
