<?php

return [

    'single' => [

        'label' => '附加',

        'modal' => [

            'heading' => '附加 :label',

            'fields' => [

                'record_id' => [
                    'label' => '資料',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => '附加',
                ],

                'attach_another' => [
                    'label' => '附加後繼續附加另一個',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => '已附加',
            ],

        ],

    ],

];
