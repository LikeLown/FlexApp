<?php

return [

    'single' => [

        'label' => '新增 :label',

        'modal' => [

            'heading' => '建立 :label',

            'actions' => [

                'create' => [
                    'label' => '建立',
                ],

                'create_another' => [
                    'label' => '建立後繼續建立另一個',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => '已建立',
            ],

        ],

    ],

];
