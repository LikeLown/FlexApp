<?php

return [

    'single' => [

        'label' => '取消關聯',

        'modal' => [

            'heading' => '取消關聯 :label',

            'actions' => [

                'dissociate' => [
                    'label' => '取消關聯',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => '已取消關聯',
            ],

        ],

    ],

    'multiple' => [

        'label' => '取消關聯所選的項目',

        'modal' => [

            'heading' => '取消關聯所選的 :label',

            'actions' => [

                'dissociate' => [
                    'label' => '取消關聯所選的項目',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => '已取消關聯',
            ],

        ],

    ],

];
