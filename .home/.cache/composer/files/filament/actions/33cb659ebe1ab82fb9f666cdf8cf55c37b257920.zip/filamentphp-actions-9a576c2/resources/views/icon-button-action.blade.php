<x-filament-actions::action
    :action="$action"
    :label="$getLabel()"
    dynamic-component="filament::icon-button"
    class="fi-ac-icon-btn-action"
/>
