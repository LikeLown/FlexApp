<?php

return [

    'field' => [
        'label' => 'البحث العام',
        'placeholder' => 'البحث',
    ],

    'no_results_message' => 'لم يتم العثور على نتائج عن البحث.',

];
