<?php

return [

    'title' => 'لوحة التحكم',

];
