<?php

return [

    'title' => 'دروسکردنی :label',

    'breadcrumb' => 'دروسکردن',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'پاشگەزبوونەوە',
            ],

            'create' => [
                'label' => 'دروسکردن',
            ],

            'create_another' => [
                'label' => 'دروسکردن و تۆمارێکی تر',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'دروسکرا',
        ],

    ],

];
