<?php

return [

    'title' => 'Dashboard',

];
