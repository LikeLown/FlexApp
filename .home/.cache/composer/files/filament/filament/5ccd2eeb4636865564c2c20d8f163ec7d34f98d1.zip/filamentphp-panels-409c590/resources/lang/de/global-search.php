<?php

return [

    'field' => [
        'label' => 'Globale Suche',
        'placeholder' => 'Suchen',
    ],

    'no_results_message' => 'Keine Ergebnisse gefunden.',

];
