<?php

return [

    'title' => 'Πίνακας ελέγχου',

];
