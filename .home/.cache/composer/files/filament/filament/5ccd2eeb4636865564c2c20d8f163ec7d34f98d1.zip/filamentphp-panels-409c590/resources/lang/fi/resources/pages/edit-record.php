<?php

return [

    'title' => 'Muokkaa :label',

    'breadcrumb' => 'Muokkaa',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Peruuta',
            ],

            'save' => [
                'label' => 'Tallenna',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Muokkaa',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Tallennettu',
        ],

    ],

];
