<?php

return [

    'title' => 'Vezérlőpult',

];
