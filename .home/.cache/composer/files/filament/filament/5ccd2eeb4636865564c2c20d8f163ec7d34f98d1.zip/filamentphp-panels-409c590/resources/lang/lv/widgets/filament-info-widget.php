<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentācija',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
