<?php

return [

    'field' => [
        'label' => 'ကမ္ဘာလုံးဆိုင်ရာ ရှာဖွေမှု',
        'placeholder' => 'ရှာမယ်',
    ],

    'no_results_message' => 'ရှာဖွေမှုရလဒ်များ မတွေ့ပါ',

];
