<?php

return [

    'field' => [
        'label' => 'Globaal zoeken',
        'placeholder' => 'Zoeken',
    ],

    'no_results_message' => 'Geen resultaten gevonden.',

];
