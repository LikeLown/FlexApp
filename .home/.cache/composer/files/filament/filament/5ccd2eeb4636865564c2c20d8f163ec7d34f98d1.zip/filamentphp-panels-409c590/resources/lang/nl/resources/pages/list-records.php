<?php

return [

    'breadcrumb' => 'Lijst',

];
