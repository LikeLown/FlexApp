<?php

return [

    'title' => ':Label bekijken',

    'breadcrumb' => 'Bekijken',

    'content' => [

        'tab' => [
            'label' => 'Bekijken',
        ],

    ],

];
