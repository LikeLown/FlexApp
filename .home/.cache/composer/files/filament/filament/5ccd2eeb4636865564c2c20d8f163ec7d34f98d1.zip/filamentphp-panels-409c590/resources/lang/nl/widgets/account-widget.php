<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Uitloggen',
        ],

    ],

    'welcome' => 'Welkom',

];
