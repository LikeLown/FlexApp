<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Documentatie',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
