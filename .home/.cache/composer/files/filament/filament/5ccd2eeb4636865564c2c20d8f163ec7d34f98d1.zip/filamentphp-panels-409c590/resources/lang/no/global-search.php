<?php

return [

    'field' => [
        'label' => 'Globalt søk',
        'placeholder' => 'Søk',
    ],

    'no_results_message' => 'Ingen resultater.',

];
