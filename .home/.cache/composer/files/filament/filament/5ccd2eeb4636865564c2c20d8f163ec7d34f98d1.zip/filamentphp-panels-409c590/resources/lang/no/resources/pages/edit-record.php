<?php

return [

    'title' => 'Endre :label',

    'breadcrumb' => 'Endre',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Avbryt',
            ],

            'save' => [
                'label' => 'Lagre endringer',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Endre',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Lagret',
        ],

    ],

];
