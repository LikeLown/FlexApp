<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Logg ut',
        ],

    ],

    'welcome' => 'Velkommen',

];
