<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Zapisz zmiany',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Zapisano',
        ],

    ],

];
