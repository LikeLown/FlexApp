<?php

return [

    'title' => 'Podgląd :label',

    'breadcrumb' => 'Podgląd',

    'content' => [

        'tab' => [
            'label' => 'Podgląd',
        ],

    ],

];
