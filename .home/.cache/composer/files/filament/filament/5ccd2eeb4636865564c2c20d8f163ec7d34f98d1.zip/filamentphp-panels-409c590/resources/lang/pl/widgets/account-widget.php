<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Wyloguj się',
        ],

    ],

    'welcome' => 'Witaj',

];
