<?php

return [

    'title' => 'Painel de Controle',

];
