<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Salvar alterações',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Salvo',
        ],

    ],

];
