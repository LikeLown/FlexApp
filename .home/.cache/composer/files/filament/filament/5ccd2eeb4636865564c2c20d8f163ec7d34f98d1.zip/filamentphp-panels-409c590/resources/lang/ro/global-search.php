<?php

return [

    'field' => [
        'label' => 'Căutare globală',
        'placeholder' => 'Căutare',
    ],

    'no_results_message' => 'Nu s-au găsit rezultate',

];
