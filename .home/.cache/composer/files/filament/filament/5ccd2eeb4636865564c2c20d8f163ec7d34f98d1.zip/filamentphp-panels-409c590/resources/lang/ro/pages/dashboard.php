<?php

return [

    'title' => 'Panoul de control',

];
