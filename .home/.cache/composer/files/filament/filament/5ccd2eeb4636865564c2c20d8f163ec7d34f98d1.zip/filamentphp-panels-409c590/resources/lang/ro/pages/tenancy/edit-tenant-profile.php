<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Salvează modificările',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Salvat cu succes',
        ],

    ],

];
