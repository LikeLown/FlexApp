<?php

return [

    'breadcrumb' => 'Listare',

];
