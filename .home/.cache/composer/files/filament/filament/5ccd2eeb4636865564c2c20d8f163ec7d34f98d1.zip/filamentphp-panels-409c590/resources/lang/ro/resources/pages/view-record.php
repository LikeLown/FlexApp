<?php

return [

    'title' => 'Vizualizare :label',

    'breadcrumb' => 'Vizualizare',

    'content' => [

        'tab' => [
            'label' => 'Vizualizare',
        ],

    ],

];
