<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Deconectare',
        ],

    ],

    'welcome' => 'Bun venit',

];
