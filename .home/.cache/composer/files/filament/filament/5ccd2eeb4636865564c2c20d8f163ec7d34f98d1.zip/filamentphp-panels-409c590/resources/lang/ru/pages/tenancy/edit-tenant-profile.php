<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Сохранить изменения',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Сохранено',
        ],

    ],

];
