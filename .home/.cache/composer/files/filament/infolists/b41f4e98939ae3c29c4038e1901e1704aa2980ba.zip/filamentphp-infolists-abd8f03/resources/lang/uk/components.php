<?php

return [

    'text_entry' => [
        'more_list_items' => 'і :count ще',
    ],

];
