<div
    {{ $attributes->class(['fi-in-entry-wrp-helper-text text-sm text-gray-500']) }}
>
    {{ $slot }}
</div>
