<?php

return [

    'modal' => [

        'heading' => 'התראות',

        'actions' => [

            'clear' => [
                'label' => 'נקה',
            ],

            'mark_all_as_read' => [
                'label' => 'סמך הכל כנקרא',
            ],

        ],

        'empty' => [
            'heading' => 'אין התראות',
            'description' => 'נסה שנית מאוחר יותר',
        ],

    ],

];
