<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Cerrar',
        ],

    ],

];
