<?php

return [

    'messages' => [
        'copied' => 'کپی شد',
    ],

];
