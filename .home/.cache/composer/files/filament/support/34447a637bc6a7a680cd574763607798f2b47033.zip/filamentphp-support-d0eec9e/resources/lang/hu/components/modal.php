<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Bezár',
        ],

    ],

];
