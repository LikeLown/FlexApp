<?php

return [

    'label' => 'Էջավորման նավիգացիա',

    'overview' => 'Ցուցադրվում են :total արդյունքներից :first֊ից :last֊ը',

    'fields' => [

        'records_per_page' => [
            'label' => 'մեկ էջում',
        ],

    ],

    'actions' => [

        'go_to_page' => [
            'label' => 'Գնալ էջ :page',
        ],

        'next' => [
            'label' => 'Հաջորդը',
        ],

        'previous' => [
            'label' => 'Նախորդ',
        ],

    ],

];
