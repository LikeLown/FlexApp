<?php

return [

    'messages' => [
        'copied' => 'Хуулав',
    ],

];
