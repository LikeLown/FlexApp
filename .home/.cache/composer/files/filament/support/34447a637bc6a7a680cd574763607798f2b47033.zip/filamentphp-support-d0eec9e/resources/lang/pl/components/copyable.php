<?php

return [

    'messages' => [
        'copied' => 'Skopiowano',
    ],

];
