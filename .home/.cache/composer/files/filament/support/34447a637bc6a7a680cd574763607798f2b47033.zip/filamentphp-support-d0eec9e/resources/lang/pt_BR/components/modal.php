<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Fechar',
        ],

    ],

];
