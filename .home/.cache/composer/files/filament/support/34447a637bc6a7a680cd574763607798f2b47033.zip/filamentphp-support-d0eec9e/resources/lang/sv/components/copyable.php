<?php

return [

    'messages' => [
        'copied' => 'Kopierad',
    ],

];
