<div
    {{
        $attributes->class([
            'flex items-center divide-x divide-gray-950/10 overflow-hidden rounded-lg shadow ring-1 ring-gray-950/10 dark:divide-white/20 dark:ring-white/20',
        ])
    }}
>
    {{ $slot }}
</div>
