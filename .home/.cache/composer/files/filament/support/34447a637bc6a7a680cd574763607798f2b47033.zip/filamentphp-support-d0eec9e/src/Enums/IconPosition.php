<?php

namespace Filament\Support\Enums;

enum IconPosition
{
    case Before;

    case After;
}
