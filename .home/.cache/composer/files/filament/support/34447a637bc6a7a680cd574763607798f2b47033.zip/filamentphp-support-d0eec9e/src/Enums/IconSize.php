<?php

namespace Filament\Support\Enums;

enum IconSize
{
    case Small;

    case Medium;

    case Large;
}
