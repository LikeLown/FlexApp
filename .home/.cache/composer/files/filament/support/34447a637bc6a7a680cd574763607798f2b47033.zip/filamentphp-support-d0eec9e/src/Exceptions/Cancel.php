<?php

namespace Filament\Support\Exceptions;

use Exception;

class Cancel extends Exception
{
}
