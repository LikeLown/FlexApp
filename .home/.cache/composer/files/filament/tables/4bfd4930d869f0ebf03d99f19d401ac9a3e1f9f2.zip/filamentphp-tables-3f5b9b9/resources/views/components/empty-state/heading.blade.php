<h4
    {{ $attributes->class(['fi-ta-empty-state-heading text-base font-semibold leading-6 text-gray-950 dark:text-white']) }}
>
    {{ $slot }}
</h4>
