<?php

namespace Filament\Tables\Actions\Modal\Actions;

use Filament\Actions\StaticAction;

/**
 * @deprecated Use `\Filament\Actions\StaticAction` instead.
 */
class Action extends StaticAction
{
}
