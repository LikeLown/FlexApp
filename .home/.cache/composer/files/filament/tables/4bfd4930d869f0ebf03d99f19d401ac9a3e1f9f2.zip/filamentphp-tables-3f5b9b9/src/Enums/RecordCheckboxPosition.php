<?php

namespace Filament\Tables\Enums;

enum RecordCheckboxPosition
{
    case BeforeCells;

    case AfterCells;
}
