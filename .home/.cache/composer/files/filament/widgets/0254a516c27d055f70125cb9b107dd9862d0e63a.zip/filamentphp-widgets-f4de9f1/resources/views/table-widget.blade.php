<x-filament-widgets::widget class="fi-wi-table">
    {{ $this->table }}
</x-filament-widgets::widget>
