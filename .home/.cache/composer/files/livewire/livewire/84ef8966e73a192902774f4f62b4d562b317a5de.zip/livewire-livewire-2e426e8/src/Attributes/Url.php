<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportQueryString\BaseUrl;

#[\Attribute]
class Url extends BaseUrl
{
    //
}
